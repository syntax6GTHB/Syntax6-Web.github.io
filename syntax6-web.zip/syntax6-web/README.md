# Syntax6 Web

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/Syntax6-the-scripter/pen/019e91c5-44bb-7f27-b680-94e548892088](https://codepen.io/editor/Syntax6-the-scripter/pen/019e91c5-44bb-7f27-b680-94e548892088).

